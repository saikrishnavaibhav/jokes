package hp.com.noofjokesexam;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.IntentCompat;
import android.support.v4.content.Loader;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.app.ProgressDialog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static android.media.ThumbnailUtils.createVideoThumbnail;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {

    public static final String URLKEY ="QUERY";
    public static String JOKEURL="http://api.icndb.com/jokes/random/";
    public static final int JOKEINT = 847;
    String jokes;
    EditText et;
    Bundle b;
    LoaderManager loaderManager;
    Loader<String> loader;
    AlertDialog alertDialog;
    AlertDialog.Builder alert;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et=findViewById(R.id.count);
         loaderManager=getSupportLoaderManager();
         loader=loaderManager.getLoader(JOKEINT);
            b=new Bundle();
            pd=new ProgressDialog(this);
            pd.setMessage("fetching jokes..");
            pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pd.setMax(12);
              alert=new AlertDialog.Builder(this);
            alert.setMessage("No Internet connection..!!");
            alert.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            alertDialog=alert.create();
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable final Bundle args) {

        return new AsyncTaskLoader<String>(this) {
            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }

            @Nullable
            @Override
            public String loadInBackground() {

                try {
                    URL url=new URL(args.getString(URLKEY));
                    HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();

                    InputStream is=httpURLConnection.getInputStream();
                    StringBuilder sb=new StringBuilder();
                    BufferedReader br=new BufferedReader(new InputStreamReader(is));
                   String joke;
                    while ((joke=br.readLine())!=null){
                        sb.append(joke);
                    }
                    return sb.toString();

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
   pd.cancel();

        if(!data.equals("")) {
            jokes=data;
            Intent i = new Intent(MainActivity.this, JokeActivity.class);
            i.putExtra("jokes", jokes);
            startActivity(i);
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }

    public void get(View view) {
        Boolean b0=MyReceiver.isConnected();
        if(b0) {

            if (!et.getText().toString().trim().equals("")) {
                Integer num = Integer.valueOf(et.getText().toString().trim());
                if (num >= 1 && num <= 100) {
                    pd.show();
                    b.putString(URLKEY, JOKEURL + et.getText().toString().trim());
                    if (loader == null) {
                        loaderManager.initLoader(JOKEINT, b, this);
                    } else {
                        loaderManager.restartLoader(JOKEINT, b, this);
                    }
                } else {
                    Toast.makeText(this, "enter number between 1 to 100", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "please enter number of jokes", Toast.LENGTH_SHORT).show();
            }
        }else{
            alertDialog.show();
        }

    }
}
