package hp.com.noofjokesexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JokeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    String jokes;
    List<String> joke;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joke);

        Bundle b=getIntent().getExtras();
        joke=new ArrayList<>();
        b.getString(MainActivity.URLKEY);
       jokes= b.getString("jokes");
        recyclerView=findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);


        try {
            JSONObject jsonObject=new JSONObject(jokes);
            JSONArray values=jsonObject.getJSONArray("value");
            for(int i=0;i<values.length();i++){
                JSONObject jokeObject=values.getJSONObject(i);
              joke.add(String.valueOf(jokeObject.get("joke")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
       recyclerView.setAdapter(new JokeAdapter(this,joke));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(JokeActivity.this,MainActivity.class));
    }
}
